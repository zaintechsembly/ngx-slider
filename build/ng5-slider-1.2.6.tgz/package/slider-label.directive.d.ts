import { ChangeDetectorRef, ElementRef, Renderer2 } from '@angular/core';
import { SliderElementDirective } from './slider-element.directive';
import * as i0 from "@angular/core";
export declare class SliderLabelDirective extends SliderElementDirective {
    private _value;
    get value(): string;
    constructor(elemRef: ElementRef, renderer: Renderer2, changeDetectionRef: ChangeDetectorRef);
    setValue(value: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SliderLabelDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SliderLabelDirective, "[ng5SliderLabel]", never, {}, {}, never, never, true, never>;
}
