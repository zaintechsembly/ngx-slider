/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="ng5-slider" />
export * from './public_api';
