import { TemplateRef } from '@angular/core';
import * as i0 from "@angular/core";
export declare class TooltipWrapperComponent {
    template: TemplateRef<any>;
    tooltip: string;
    placement: string;
    content: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<TooltipWrapperComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TooltipWrapperComponent, "ng5-slider-tooltip-wrapper", never, { "template": { "alias": "template"; "required": false; }; "tooltip": { "alias": "tooltip"; "required": false; }; "placement": { "alias": "placement"; "required": false; }; "content": { "alias": "content"; "required": false; }; }, {}, never, never, true, never>;
}
